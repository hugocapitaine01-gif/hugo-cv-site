const els=document.querySelectorAll('.project,.manifesto,.exp-row,.gallery-grid>div,.skills,.education');
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting)e.target.classList.add('show')}),{threshold:.12});
els.forEach(e=>{e.style.opacity='0';e.style.transform='translateY(28px)';e.style.transition='opacity .7s ease, transform .7s ease';io.observe(e)});
const s=document.createElement('style');s.textContent='.show{opacity:1!important;transform:none!important}';document.head.appendChild(s);
